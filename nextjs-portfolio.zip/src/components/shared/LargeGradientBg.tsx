export const LargeGradientBg = () => {
  return <div className="footerGradientBg"></div>;
};
