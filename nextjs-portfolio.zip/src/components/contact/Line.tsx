import contactStyles from "@/styles/contact.module.css";

export const Line = () => {
  return <div className={contactStyles.line}></div>;
};
